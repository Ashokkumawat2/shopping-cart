const router=require('express').Router()
const regc=require('../controllers/regcontrollers')
const productc=require('../controllers/productcontroller')
const upload=require('../helpers/multer')



router.post('/register',regc.register)
router.post('/login',regc.logincheck)
router.post('/addproduct',upload.single('img'),productc.addproduct)
router.get('/allproducts',productc.allproducts)
router.get('/singleproduct/:id',productc.singleproduct)
router.put('/productupdate/:id', upload.single('img'),productc.productupdate)
router.get('/stockproduct',productc.stockproduct)
router.post('/cart',productc.cart)
router.post('/checkout/:username',productc.checkout)
router.delete('/adminproductdelete/:id',productc.deleteproduct)
router.get('/productdetails/:id',productc.productdetails)











module.exports=router