const Reg=require('../models/reg')
const bcrypt=require('bcrypt')



exports.register =  async (req, res) => {
    const{username,password}=req.body
    const convertedpass=await bcrypt.hash(password,10)
    //console.log(convertedpass)
    const usercheck=await Reg.findOne({username:username})
    console.log(usercheck)
    try{
        if(usercheck==null){
    const record=new Reg({username:username,password:convertedpass})
    record.save()
    res.json({
        status:201,
        apiData:record,
        message:` ${username} successfully account has been created`
    })
}else{
    res.json({
        status:400,
        message:`${username} is already taken`
    })
}
    }catch(error){
        res.json({
            status:400,
            message:error.message
        })

    }
    


    // Hash the password using bcrypt with a cost factor of 10
    

    // Log the hashed password to the console (for debugging purposes)
    //console.log(convertedpass);

    // Add code here to save the user with the hashed password to the database
    // Example: const newUser = new Reg({ username, password: convertedpass });
    //          await newUser.save();

    // Send a response to the client (you may want to customize this based on your needs)
    //res.status(200).json({ message: 'Registration successful' });
};
exports.logincheck= async(req,res)=>{
    const{username,password}=req.body
    try{
    const record=await Reg.findOne({username:username})
    if(record!==null){
       const passwordcheck= await bcrypt.compare( password,record.password)
       if(passwordcheck){
        res.json({
            status:200,
            apiData:record.username
        })
    }else{
        res.json({
            status:400,
            message:'Wrong password'
        })
    }
    }else{
        res.json({
            status:400,
            message:'Wrong username'
        })
    }
}catch(error){
    res.json({
        status:400,
        message:error.message
    })
}
}
