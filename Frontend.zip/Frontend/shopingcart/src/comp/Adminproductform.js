import { useState } from "react";
import Left from "./Left";

function Adminproductform() {
    const[name,setName]=useState('')
    const[desc,setDesc]=useState('')
    const[price,setPrice]=useState('')
    const[qty,setQty]=useState('')
    const[productimg,setProductimg]=useState('')
    const[message,setMessage]=useState('')
    function handleform(e){
        e.preventDefault()
        console.log(name,desc,price,qty)
        let Data=new FormData()
        Data.append('name',name)
        Data.append('desc',desc)
        Data.append('price',price)
        Data.append('qty',qty)
        Data.append('img',productimg)
        fetch('/api/addproduct',{
            method:"POST",
            body:Data
        }).then((result)=>{return result.json()}).then((data)=>{
            //console.log(data)
            if(data.status===201){
                setMessage(data.message)

            }else{
                setMessage(data.message)


            }
        })

    }
    return ( 
        <section id="mid">
            <div className="container">
            <div className="row">
                <Left/>
            <div className="col-md-9">
                <h2>Add New Product Here</h2>
                <p>{message}</p>
                <form onSubmit={(e)=>{handleform(e)}}>
                    <label>Product Name</label>
                    <input type="text" className="form-control"
                    value={name}
                    onChange={(e)=>{setName(e.target.value)}}
                    />
                    <label>Product Description</label>
                    <input type="text" className="form-control"
                    value={desc}
                    onChange={(e)=>{setDesc(e.target.value)}}
                    
                    />
                    <label>Product Price</label>
                    <input type="number" className="form-control"
                     value={price}
                     onChange={(e)=>{setPrice(e.target.value)}}
                    
                    />
                    <label>Product Quantity </label>
                    <input type="text" className="form-control"
                    value={qty}
                    onChange={(e)=>{setQty(e.target.value)}}
                    
                    />
                    <label>Product Image</label>
                    <input type="file" className=" form-control"
                    onChange={(e)=>{setProductimg(e.target.files[0])}}
                    
                    />
                    <button type="submit" className="form-control btn btn-danger mt-2">Add product</button>
                </form>
            </div>


            </div>

            </div>

        </section>
     );
}

export default Adminproductform;