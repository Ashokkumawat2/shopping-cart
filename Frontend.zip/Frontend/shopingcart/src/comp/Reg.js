import { useState } from 'react';
import{Link } from 'react-router-dom'
function Reg() {
    const[username,setUsername]=useState('')
    const[password,setPassword]=useState('')
    const[message,setMessage]=useState('')
    function handleform(e){
        e.preventDefault()
        const formdata={username,password}
        fetch('/api/register',{
            method:'POST',
            headers:{"Content-type":"application/json"},
            body:JSON.stringify(formdata)
        }).then((result)=>{return result.json()}).then((data)=>{
            console.log(data)
            if(data.status===201){
                setMessage(data.message)
            }else{
                setMessage(data.message)
            }
        })

    }
    return ( 
        <section id="login">
        <div className="container">
        <div className="row">
        <div className="col-md-6 left-side">
                    <img src="./images/signup.png" alt="" className="img-fluid mb-2" width="400"/>
                    <h2>Register Now</h2>
                    <p>Get Started with New account</p>
                </div>
        <div className="col-md-6 right-side mt-4">
        <h3>Hello,</h3>
         <h5>We are happy to have you back</h5>
            <p>{message}</p>
            <form onSubmit={(e)=>{handleform(e)}}>
                <label>Username/Email</label>
                <input type="text"  className="form-control form-control-lg bg-light mt-5"
                value={username}
                onChange={(e)=>{setUsername(e.target.value)}}
                
                />
                <label>Password</label>
                <input type="text" className="form-control form-control-lg bg-light mt-3"
                value={password}
                onChange={(e)=>{setPassword(e.target.value)}}
                />
                        <button type="submit" className="btn btn-dark btn-lg form-control mt-3">Register</button>
            </form>
            <Link to="/"><button className="btn  btn-light btn-lg form-control mt-3">Already Have an Account? Login Here</button></Link>

        </div>
        <div className="col-md-4"></div>

        </div>

        </div>

    </section>
     );
}

export default Reg;