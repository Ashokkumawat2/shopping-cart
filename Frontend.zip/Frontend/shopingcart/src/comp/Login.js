import { useContext, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Contextapi } from "../Contextapi";

function Login() {
    const navigate=useNavigate()
    const{setLoginname,loginname}=useContext(Contextapi)
    const[username,setUsername]=useState('')
    const[password,setPassword]=useState('')
    const[message,setMessage]=useState('')
    function handleform(e){
        e.preventDefault()
        const data={username,password}
        fetch('api/login',{
            method:"POST",
            headers:{"Content-type":"application/json"},
            body:JSON.stringify(data)

        }).then((result)=>{return result.json()}).then((data)=>{
            //console.log(data)
            if(data.status===200){
                localStorage.setItem('loginname',data.apiData)
                setLoginname(localStorage.getItem('loginname'))
                if(data.apiData==='admin'){
                    navigate('/dashboard')


                }else{
                    navigate('/products')
                }
                


            }else{
                setMessage(data.message)

            }
        })
    }
    return ( 
        <section id="login">
            <div className="container">
            <div className="row">
            <div className="col-md-6 left-side">
                    <img src="./images/login1.png" alt="" className="img-fluid mb-2" width="400"/>
                    <h2>Be Verfied</h2>
                    <p>Please Login with Your Registered Email and Password</p>
                </div>
            <div className="col-md-6 right-side">
            <div className="text-center">
                        <img src="./images/welcome.png" alt="" className="img-fluid" width="400px"/>
                    </div>
                <p>{message}</p>
                <form onSubmit={(e)=>{handleform(e)}}>
                    <label>Username/Email</label>
                    <input type="text" 
                    value={username}
                    onChange={(e)=>{setUsername(e.target.value)}} className="form-control form-control-lg bg-light mt-4"/>
                    <label>Password</label>
                    <input type="text" 
                    value={password}
                    onChange={(e)=>{setPassword(e.target.value)}}  className="form-control form-control-lg bg-light mt-3"/>
                        <button type="submit" className="btn btn-dark btn-lg form-control mt-3">Login</button>
                </form>
                <Link to='/reg'><button className="btn btn-primary form-control mt-4">Create Account</button></Link>
            </div>
            <div className="col-md-4"></div>

            </div>

            </div>

        </section>
     );
}

export default Login;