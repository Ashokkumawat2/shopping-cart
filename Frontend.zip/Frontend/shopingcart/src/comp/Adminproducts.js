import { Link, useNavigate } from "react-router-dom";
import Left from "./Left";
import { useEffect, useState } from "react";

function Adminproducts() {
    const navigate=useNavigate()
    const[message,setMessage]=useState('')
    const[products,setProducts]=useState([])
    useEffect(()=>{
        fetch('/api/allproducts').then((result)=>{return result.json()}).then((data)=>{
            //console.log(data)
            if(data.status==200){
                setProducts(data.apiData)

            }else{
                setMessage(data.message)

            }
        })
    },[products])
    function handleproductdelete(e,id){
        fetch(`/api/adminproductdelete/${id}`,{
            method:"DELETE",
        }).then((result)=>{return result.json()}).then((data)=>{
            //console.log(data)
            if(data.status===200){
                navigate('/adminproducts')
            

            }else{
                setMessage(data.message)

            }
        })
    }
    return ( 
        <section id="mid">
            <div className="container">
            <div className="row">
                <Left/>
            <div className="col-md-9">
                <h2>product Management</h2>
                <p>{message}</p>
                <Link to='/adminnewproduct'><button className="btn btn-success form-control">Add New product</button></Link>
                <table className="table table-hover">
                    <thead >
                        <tr>
                            <th>S.NO</th>
                            <th>Product Name</th>
                            <th>Product Description</th>
                            <th>Product Price</th>
                            <th>Product Image</th>
                            <th>Product Quantity</th>
                            <th>Product Status</th>
                            <th>Product Update</th>
                            <th>Product Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        {products.map((result,key)=>(
                             <tr key={result._id}>
                             <td>{key+1}</td>
                             <td>{result.name}</td>
                             <td>{result.desc}</td>
                             <td><img style={{width:"200px"}} src={`/upload/${result.img}`} alt=""/></td>
                             <td>{result.price}</td>
                            <td>{result.qty}</td>
                             <td>{result.status}</td>
                             <td><Link to ={`/adminproductupdate/${result._id}`}><button className="btn btn-outline-primary">Update</button></Link></td>
                             <td><button onClickCapture={(e)=>{handleproductdelete(e,result._id)}} className="btn btn-outline-danger">Delete</button></td>

                             </tr>

                        ))}
                       
                    </tbody>
                </table>
            </div>


            </div>

            </div>

        </section>
     );
}

export default Adminproducts;