import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Productstr from "./Productstr";

function Products() {
    const[message,setMessage]=useState('')
    const[products,setProducts]=useState([])
    useEffect(()=>{
        fetch('/api/stockproduct').then((result)=>{return result.json()}).then((data)=>{
            //console.log(data)
            if(data.status===200){
                setProducts(data.apiData)


            }else{
                setMessage(data.message)

            }
        })
    },[])
    return ( 
        <div id="products">
        {products.map((result,key)=>(
            <Productstr product={result} />

        ))}
        </div>
        
   
     );
}

export default Products;