import Left from "./Left";

function Dashboard() {
    return ( 
        <section id="dashboard">
            <div className="container">
            <div className="row">
                <Left/>
                </div>
            <div className="col-md-9">
            <h1>Shopping-cart Admin Dashboard</h1>
            <div className="content">
            <img src="./images/dashboard-img.png" alt="" className="img-fluid"></img>


            </div>


            </div>


            

            </div>

        </section>
     );
}

export default Dashboard;