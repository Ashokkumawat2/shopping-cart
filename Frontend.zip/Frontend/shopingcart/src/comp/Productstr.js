import { useContext } from 'react';
import {Link} from 'react-router-dom'
import { Contextapi } from '../Contextapi';
function Productstr(props) {
    const{cart,setCart}=useContext(Contextapi)
    const{product}=props
    function handleaddcart(e,productid){
        //console.log(productid)
        let _cart={...cart}
        if(!_cart.item){
            _cart.item={}
        }
        if(!_cart.item[productid]){
            _cart.item[productid]=1
        }else{
            _cart.item[productid]+=1
        }
        if(!_cart.totalitems){
            _cart.totalitems=1
        }else{
            _cart.totalitems+=1
        }
        setCart(_cart)
        console.log(cart)
        
    }
    return ( 
        <section >
        <div className="container">
        <div className="row">
        <div className="col-md-3">
        <div className="card" style={{width:'18rem'}}>
<img  style ={{width:'50%'}}src={`/upload/${product.img}`} className="card-img-top" alt="..."/>
<div className="card-body">
<h5 className="card-title">{product.name}</h5>
<p className="card-text">{product.desc}</p>
<p className="card-text"> Price:Rs {product.price}</p>
<button  className="btn btn-primary me-2" onClick={(e)=>{handleaddcart(e,product._id)}}>ADD Cart</button>
<Link to={`/productdetails/${product._id}`}><button className="btn btn-primary">Deatils</button></Link>
</div>
</div>
        </div>
       

        </div>

        </div>
    </section>
     );
}

export default Productstr;