import { useContext, useEffect, useState } from "react";
import { Contextapi } from "../Contextapi";
import { useNavigate } from "react-router-dom";

function Cart() {
    let totalamount=0
    const navigate=useNavigate()
    const{cart,setCart,loginname}=useContext(Contextapi)
    const [message,setMessage]=useState('')
    const[products,setproducts]=useState([])
    useEffect(()=>{
        if(!cart.item){
            return
        }
        fetch('/api/cart',{
            method:'POST',
            headers:{"Content-Type":"application/json"},
            body:JSON.stringify({ids:Object.keys(cart.item)})
        }).then((result)=>{return result.json()}).then((data)=>{
            //console.log(data)
            if(data.status===200){
                setproducts(data.apiData)
                
            }else{
                setMessage(data.message)

            }
        })
    },[])
    function handleqty(id){
      return  cart.item[id]

    }
    function handleincrement(e,id,qty){
        let currentqty=handleqty(id)
        if(currentqty===qty){
            alert('you have reached to Max qunatity')
            return
        }
        let _cart={...cart}
        _cart.item[id]=currentqty+1
        _cart.totalitems +=1
        setCart(_cart)
    }
    function handledecrement(e,id){
        let currentqty=handleqty(id)
        if(currentqty===1){
            alert('you have reached to min qunatity')
            return
        }
        let _cart={...cart}
        _cart.item[id]=currentqty-1
        _cart.totalitems -=1
        setCart(_cart)
    }
    function handleprice(id,price){
       let tprice=handleqty(id)*price
       totalamount+= tprice
       return tprice
    }

    function handledelete(e,id){
        let current_qnty=handleqty(id)
        let _cart={...cart}
        delete _cart.item[id]
        _cart.totalitems -= current_qnty
        setCart(_cart)


    }
   
   
    function handlecheckout(e){
        fetch(`/api/checkout/${loginname}`,{
            method:"POST",
            headers:{"Content-Type":"application/json"},
            body:JSON.stringify(cart.item)
        })
        setCart('')
        navigate('/products')
    }
    return ( 
        <>
        {products.length!=0?
        <div className="container">
        <div className="row">
        <div className="col-md-12">
        <h2>Cart</h2>
        <table className="table table-hover">
            <thead>
                <tr>
                    <th>S.No</th>
                    <th>product Name</th>
                    <th>product Quantity</th>
                    <th>product Price</th>
                    <th>product Delete</th>
                </tr>
            </thead>
            <tbody>
                {products.map((result,sn)=>(
                     <tr>
                     <td>{sn+1}</td>
                     <td>{result.name}</td>
                     <td><button onClick={(e)=>{handleincrement(e,result._id,result.qty)}}>+</button>{handleqty(result._id)}<button onClick={(e)=>{handledecrement(e,result._id)}}>-</button></td>
                     <td>{handleprice(result._id,result.price)} <i class="bi bi-currency-rupee"></i></td>
                     <td><button onClick={(e)=>{handledelete(e,result._id)}} >Delete</button></td>
                   

                 </tr>

                ))}
                <tr>
                    <td colSpan="5">Total Amount:{totalamount}</td>
                </tr>
                <tr>
                    <td colSpan="5"><button className="btn btn-success form-control" onClick={(e)=>{handlecheckout(e)}}>Checkout</button></td>
                </tr>
                
               
            </tbody>
        </table>

        </div>

        </div>

        </div>
        :
        <img src="./images/emptycart.png" alt="" className="img-fluid"></img>

                }
        
        </>
     );
}

export default Cart;